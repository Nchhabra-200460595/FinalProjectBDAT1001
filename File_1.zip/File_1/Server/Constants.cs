﻿namespace Server
{
    public static class Constants
    {
        public const string Issuer = Audiance;
        public const string Audiance = "https://localhost:44324/";
        public const string Secret = "hfgdhjfhjgjgjgjgjjrurfjfrgvufvnuflllbfgfjkfkfkf";
    }
}